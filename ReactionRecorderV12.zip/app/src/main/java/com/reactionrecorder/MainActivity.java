package com.reactionrecorder;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private FrameLayout root;
    private PreviewView camera;
    private PlayerView source;
    private WebView youtubeView;
    private ExoPlayer player;
    private Button pick, youtube, play, rewind, forward, record, settings;
    private FrameLayout pipContainer;
    private View emptyCard, pipEmpty, resizeHandle;
    private TextView sourceStatus, sourceTime, recordingBadge;
    private float dragDownX, dragDownY, startTx, startTy;
    private float resizeDownX, resizeDownY;
    private int resizeStartW, resizeStartH;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    private final Runnable progressTicker = new Runnable() { @Override public void run() { updateSourceTime(); uiHandler.postDelayed(this, 500); } };
    private Uri sourceUri;
    private String youtubeVideoId;
    private boolean youtubeReady;
    private boolean recording;
    private Integer selectedInputDeviceId;
    private String selectedInputName = "Phone microphone (default)";
    private AudioVideoRecorder.RecordingSettings recordingSettings = new AudioVideoRecorder.RecordingSettings();
    private static final int CAPTURE = 77;
    private android.content.SharedPreferences prefs;

    private final BroadcastReceiver recorderReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a=intent.getAction();
            if(RecordingService.ACTION_STARTED.equals(a)) {
                recording=true; record.setText("■"); recordingBadge.setVisibility(View.VISIBLE); Toast.makeText(MainActivity.this,"Recording started",Toast.LENGTH_SHORT).show();
            } else if(RecordingService.ACTION_FINISHED.equals(a)) {
                recording=false; record.setText("●"); recordingBadge.setVisibility(View.GONE); String s=intent.getStringExtra(RecordingService.EXTRA_URI);
                if(s!=null) { Intent share=new Intent(Intent.ACTION_SEND); share.setType("video/mp4"); share.putExtra(Intent.EXTRA_STREAM,Uri.parse(s)); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                Toast.makeText(MainActivity.this,"Saved to Movies / Reaction Recorder",Toast.LENGTH_LONG).show();
            } else if(RecordingService.ACTION_FAILED.equals(a)) {
                recording=false; record.setText("●"); recordingBadge.setVisibility(View.GONE); Toast.makeText(MainActivity.this,"Recording failed: "+intent.getStringExtra(RecordingService.EXTRA_ERROR),Toast.LENGTH_LONG).show();
            }
        }
    };

    private final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->startCamera());
    private final ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
        if(r.getResultCode()==RESULT_OK&&r.getData()!=null){sourceUri=r.getData().getData();try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}loadSource(sourceUri);}
    });

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.reactionrecorder.R.layout.activity_main);
        root=findViewById(R.id.root);camera=findViewById(R.id.camera);source=findViewById(R.id.source);youtubeView=findViewById(R.id.youtube_view);pick=findViewById(R.id.pick);youtube=findViewById(R.id.youtube);play=findViewById(R.id.play);rewind=findViewById(R.id.rewind);forward=findViewById(R.id.forward);record=findViewById(R.id.record);settings=findViewById(R.id.settings);pipContainer=findViewById(R.id.pip_container);emptyCard=findViewById(R.id.empty_card);pipEmpty=findViewById(R.id.pip_empty);sourceStatus=findViewById(R.id.source_status);sourceTime=findViewById(R.id.source_time);recordingBadge=findViewById(R.id.recording_badge);resizeHandle=findViewById(R.id.pip_resize_hint);
        prefs=getSharedPreferences("recorder",MODE_PRIVATE);loadPrefs();
        player=new ExoPlayer.Builder(this).setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL).build(),true).build();source.setPlayer(player);
        setupYoutubeWebView();
        if(Build.VERSION.SDK_INT>=29){try{((AudioManager)getSystemService(AUDIO_SERVICE)).setAllowedCapturePolicy(android.media.AudioAttributes.ALLOW_CAPTURE_BY_ALL);}catch(Exception ignored){}}
        pick.setOnClickListener(v->choose()); youtube.setOnClickListener(v->youtubeDialog()); play.setOnClickListener(v->toggleSource()); rewind.setOnClickListener(v->seekSource(-10)); forward.setOnClickListener(v->seekSource(10)); record.setOnClickListener(v->{if(!recording)requestCapture();else stopRecording();}); settings.setOnClickListener(v->settingsDialog());
        setupPipDragging();
        setupPipResize();
        uiHandler.post(progressTicker);
        player.addListener(new androidx.media3.common.Player.Listener(){ @Override public void onIsPlayingChanged(boolean isPlaying){ play.setText(isPlaying ? "Ⅱ" : "▶"); sourceStatus.setText(isPlaying ? "Playing source" : "Source paused"); } @Override public void onPlaybackStateChanged(int state){ updateSourceTime(); }});
        IntentFilter f=new IntentFilter();f.addAction(RecordingService.ACTION_STARTED);f.addAction(RecordingService.ACTION_FINISHED);f.addAction(RecordingService.ACTION_FAILED);ContextCompat.registerReceiver(this,recorderReceiver,f,ContextCompat.RECEIVER_NOT_EXPORTED);
        perms.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});
    }

    private void loadPrefs(){recordingSettings.codec=prefs.getString("codec","HEVC");recordingSettings.width=prefs.getInt("width",1080);recordingSettings.height=prefs.getInt("height",1920);recordingSettings.fps=prefs.getInt("fps",30);recordingSettings.bitrate=prefs.getInt("bitrate",5_000_000);}
    private void savePrefs(){prefs.edit().putString("codec",recordingSettings.codec).putInt("width",recordingSettings.width).putInt("height",recordingSettings.height).putInt("fps",recordingSettings.fps).putInt("bitrate",recordingSettings.bitrate).apply();}

    private void choose(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);picker.launch(i);}
    private void loadSource(Uri u){
        stopYouTubePlayback(); youtubeVideoId=null; youtubeReady=false; youtubeView.setVisibility(View.GONE); source.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE);
        player.setMediaItem(MediaItem.fromUri(u));
        player.prepare();
        player.pause();
        player.seekTo(0);
        play.setText("▶");
        emptyCard.setVisibility(View.GONE);
        sourceStatus.setText("Source ready • tap ▶ to play");
        sourceTime.setText("00:00 / --:--");
    }
    private boolean hasSource(){ return sourceUri!=null || youtubeVideoId!=null; }

    private void toggleSource(){
        if(!hasSource()){ choose(); return; }
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){ if(player && player.getPlayerState()===1){player.pauseVideo();}else if(player){player.playVideo();} })();", null);
        } else if(player.isPlaying()) player.pause(); else player.play();
    }

    private void seekSource(int seconds){
        if(youtubeVideoId!=null){
            if(youtubeReady) youtubeView.evaluateJavascript("(function(){if(player){player.seekTo(Math.max(0,player.getCurrentTime()+"+seconds+"),true);}})();", null);
        } else if(player!=null){
            if(seconds<0) player.seekBack(); else player.seekForward();
        }
    }

    private void updateSourceTime(){
        if(player==null || sourceTime==null) return;
        if(youtubeVideoId!=null){
            if(!youtubeReady) return;
            youtubeView.evaluateJavascript("(function(){return JSON.stringify({p:player?player.getCurrentTime():0,d:player?player.getDuration():0,s:player?player.getPlayerState():-1});})()", value -> {
                try {
                    String v=value==null?"":value.replace("\\\"","\"").replace("\"{", "{").replace("}\"", "}");
                    org.json.JSONObject o=new org.json.JSONObject(v);
                    long pos=(long)(o.optDouble("p",0)*1000); long dur=(long)(o.optDouble("d",0)*1000);
                    sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
                    int state=o.optInt("s",-1); play.setText(state==1?"Ⅱ":"▶");
                    sourceStatus.setText(state==1?"Playing YouTube source":"YouTube source paused");
                } catch(Exception ignored) {}
            });
            return;
        }
        long pos=Math.max(0,player.getCurrentPosition()); long dur=player.getDuration();
        sourceTime.setText(formatTime(pos)+" / "+(dur>0?formatTime(dur):"--:--"));
        if(recording && recordingBadge!=null){ long t=System.currentTimeMillis(); sourceTime.invalidate(); }
    }

    private String formatTime(long ms){ long total=ms/1000; return String.format(Locale.US,"%02d:%02d",total/60,total%60); }

    private void setupPipDragging(){
        View handle=findViewById(R.id.pip_drag_hint);
        handle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    dragDownX=e.getRawX(); dragDownY=e.getRawY();
                    startTx=pipContainer.getTranslationX(); startTy=pipContainer.getTranslationY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float nx=startTx+(e.getRawX()-dragDownX);
                    float ny=startTy+(e.getRawY()-dragDownY);
                    float baseLeft=pipContainer.getLeft();
                    float baseTop=pipContainer.getTop();
                    float minX=-baseLeft+8;
                    float maxX=root.getWidth()-pipContainer.getWidth()-baseLeft-8;
                    float minY=-baseTop+8;
                    float maxY=root.getHeight()-pipContainer.getHeight()-baseTop-8;
                    pipContainer.setTranslationX(Math.max(minX,Math.min(nx,maxX)));
                    pipContainer.setTranslationY(Math.max(minY,Math.min(ny,maxY)));
                    return true;
                case MotionEvent.ACTION_UP:
                    v.performClick();
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    return true;
            }
            return false;
        });
    }

    private void setupPipResize(){
        resizeHandle.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    resizeDownX=e.getRawX(); resizeDownY=e.getRawY();
                    resizeStartW=pipContainer.getWidth(); resizeStartH=pipContainer.getHeight();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    int nw=Math.max(200,Math.min(520,resizeStartW+Math.round(e.getRawX()-resizeDownX)));
                    float ratio=resizeStartH/(float)Math.max(1,resizeStartW);
                    int nh=Math.max(200,Math.min(420,Math.round(nw*ratio)));
                    ViewGroup.LayoutParams lp=pipContainer.getLayoutParams(); lp.width=nw; lp.height=nh; pipContainer.setLayoutParams(lp); return true;
                case MotionEvent.ACTION_UP: v.performClick(); return true;
                default: return true;
            }
        });
    }

    private void youtubeDialog(){
        EditText e=new EditText(this);
        e.setHint("https://www.youtube.com/watch?v=...");
        new AlertDialog.Builder(this)
                .setTitle("YouTube source")
                .setMessage("Paste a YouTube video link. It will play inside the reaction recorder; the app does not download the YouTube video.")
                .setView(e)
                .setNegativeButton("Cancel",null)
                .setPositiveButton("Load in app",(d,w)->{
                    String id=extractYouTubeId(e.getText().toString().trim());
                    if(id==null) Toast.makeText(this,"That doesn't look like a supported YouTube video link.",Toast.LENGTH_LONG).show();
                    else loadYouTube(id);
                }).show();
    }

    private String extractYouTubeId(String raw){
        if(raw==null||raw.isEmpty()) return null;
        try{
            String s=raw.trim();
            if(!s.matches("https?://.*")) return null;
            Uri u=Uri.parse(s);
            String host=u.getHost()==null?"":u.getHost().toLowerCase(Locale.US);
            if(host.equals("youtu.be")){ String p=u.getPath(); return cleanYouTubeId(p==null?null:p.substring(p.startsWith("/")?1:0)); }
            if(host.equals("youtube.com")||host.endsWith(".youtube.com")){
                String v=u.getQueryParameter("v");
                if(v!=null) return cleanYouTubeId(v);
                String p=u.getPath();
                if(p!=null){
                    String[] a=p.split("/");
                    if(a.length>=3 && ("shorts".equals(a[1])||"embed".equals(a[1])||"live".equals(a[1]))) return cleanYouTubeId(a[2]);
                }
            }
        }catch(Exception ignored){}
        return null;
    }

    private String cleanYouTubeId(String id){
        if(id==null) return null;
        id=id.trim();
        if(id.length()!=11) return null;
        return id.matches("[A-Za-z0-9_-]{11}")?id:null;
    }

    private void loadYouTube(String id){
        stopYouTubePlayback(); youtubeVideoId=id; sourceUri=null; youtubeReady=false;
        player.pause(); source.setVisibility(View.GONE); youtubeView.setVisibility(View.VISIBLE); pipEmpty.setVisibility(View.GONE); emptyCard.setVisibility(View.GONE);
        sourceStatus.setText("Loading YouTube source…"); sourceTime.setText("00:00 / --:--"); play.setText("▶");
        String html="<!doctype html><html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no\"></head><body style=\"margin:0;background:#090C12;overflow:hidden\"><div id=\"player\" style=\"width:100vw;height:100vh\"></div><script>var player;function onYouTubeIframeAPIReady(){player=new YT.Player('player',{width:'100%',height:'100%',videoId:'"+id+"',playerVars:{playsinline:1,controls:1,rel:0,enablejsapi:1,origin:'https://reactionrecorder.app'},events:{onReady:function(){AndroidYT.ready();},onStateChange:function(e){AndroidYT.state(e.data);},onError:function(e){AndroidYT.error(e.data);}}});}var t=document.createElement('script');t.src='https://www.youtube.com/iframe_api';document.head.appendChild(t);</script></body></html>";
        youtubeView.loadDataWithBaseURL("https://reactionrecorder.app/",html,"text/html","UTF-8",null);
    }

    private void stopYouTubePlayback(){
        if(youtubeView==null) return;
        try {
            youtubeView.evaluateJavascript("(function(){try{if(player){player.stopVideo();}}catch(e){}})();", null);
        } catch(Exception ignored) {}
        try { youtubeView.loadUrl("about:blank"); } catch(Exception ignored) {}
        youtubeReady=false;
    }

    private void setupYoutubeWebView(){
        youtubeView.setVisibility(View.GONE);
        WebSettings ws=youtubeView.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setMediaPlaybackRequiresUserGesture(true); ws.setBuiltInZoomControls(false); ws.setDisplayZoomControls(false);
        youtubeView.setBackgroundColor(android.graphics.Color.rgb(9,12,18));
        youtubeView.setWebChromeClient(new WebChromeClient());
        youtubeView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){ return false; }
        });
        youtubeView.addJavascriptInterface(new Object(){
            @android.webkit.JavascriptInterface public void ready(){ runOnUiThread(()->{youtubeReady=true; sourceStatus.setText("YouTube ready • tap ▶ to play");}); }
            @android.webkit.JavascriptInterface public void state(int state){ runOnUiThread(()->{ if(state==1) sourceStatus.setText("Playing YouTube source"); else if(state==2) sourceStatus.setText("YouTube source paused"); play.setText(state==1?"Ⅱ":"▶"); }); }
            @android.webkit.JavascriptInterface public void error(int code){ runOnUiThread(()->Toast.makeText(MainActivity.this,"YouTube player error: "+code,Toast.LENGTH_LONG).show()); }
        },"AndroidYT");
    }

    private void settingsDialog(){String[] items={"Video quality • "+recordingSettings.summary(),"Aspect ratio • "+aspectRatioName(),"Estimated size • "+estimate10Min(),"Audio input • "+selectedInputName,"Audio mix • Mic + source audio"};new AlertDialog.Builder(this).setTitle("Recording settings").setItems(items,(d,w)->{if(w==0)chooseVideoQuality();else if(w==1)chooseAspectRatio();else if(w==2)showSizeInfo();else if(w==3)chooseAudioInput();else Toast.makeText(this,"Both microphone and source playback are included in the final audio.",Toast.LENGTH_LONG).show();}).show();}

    private String aspectRatioName(){float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-16f/9f)<.03f)return"16:9";if(Math.abs(r-9f/16f)<.03f)return"9:16";if(Math.abs(r-1f)<.03f)return"1:1";if(Math.abs(r-4f/3f)<.03f)return"4:3";return"Custom";}
    private void chooseAspectRatio(){String[] c={"9:16 vertical","16:9 landscape","1:1 square","4:3 landscape"};float r=recordingSettings.width/(float)recordingSettings.height;int checked=Math.abs(r-9f/16f)<.03f?0:Math.abs(r-16f/9f)<.03f?1:Math.abs(r-1)<.03f?2:3;new AlertDialog.Builder(this).setTitle("Aspect ratio").setSingleChoiceItems(c,checked,(d,w)->{int longSide=Math.max(recordingSettings.width,recordingSettings.height);if(w==0){recordingSettings.width=even(Math.round(longSide*9f/16f));recordingSettings.height=even(longSide);}else if(w==1){recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*9f/16f));}else if(w==2){recordingSettings.width=even(longSide);recordingSettings.height=even(longSide);}else{recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*3f/4f));}savePrefs();d.dismiss();Toast.makeText(this,"Aspect ratio: "+aspectRatioName(),Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    private int even(int n){return Math.max(2,n&~1);}

    private void chooseVideoQuality(){String[] c={"HEVC • 1080p • 30 • 5 Mbps","HEVC • 1080p • 30 • 8 Mbps","H.264 • 1080p • 30 • 8 Mbps","HEVC • 720p • 30 • 3 Mbps","Custom"};new AlertDialog.Builder(this).setTitle("Video quality").setItems(c,(d,w)->{if(w==0)applyPreset("HEVC",1080,30,5_000_000);else if(w==1)applyPreset("HEVC",1080,30,8_000_000);else if(w==2)applyPreset("H.264",1080,30,8_000_000);else if(w==3)applyPreset("HEVC",720,30,3_000_000);else customQualityDialog();}).show();}
    private void applyPreset(String codec,int longSide,int fps,int bitrate){recordingSettings.codec=codec;recordingSettings.fps=fps;recordingSettings.bitrate=bitrate;boolean vert=recordingSettings.height>recordingSettings.width;float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-1)<.03f){recordingSettings.width=longSide;recordingSettings.height=longSide;}else if(Math.abs(r-4f/3f)<.08f){recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*3f/4f);}else if(vert){recordingSettings.height=longSide;recordingSettings.width=Math.round(longSide*9f/16f);}else{recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*9f/16f);}recordingSettings.width=even(recordingSettings.width);recordingSettings.height=even(recordingSettings.height);savePrefs();Toast.makeText(this,"Quality: "+recordingSettings.summary()+"\nEstimated 10 min: "+estimate10Min(),Toast.LENGTH_LONG).show();}

    private void customQualityDialog(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);int p=(int)(16*getResources().getDisplayMetrics().density);box.setPadding(p,0,p,0);EditText fps=new EditText(this);fps.setHint("FPS 15–60");fps.setInputType(2);fps.setText(String.valueOf(recordingSettings.fps));EditText mbps=new EditText(this);mbps.setHint("Bitrate Mbps 1–30");mbps.setInputType(2|8192);mbps.setText(String.valueOf(Math.max(1,recordingSettings.bitrate/1_000_000)));box.addView(fps);box.addView(mbps);String[] codecs={"HEVC (H.265)","H.264 (AVC)"};final int[] choice={recordingSettings.codec.equals("H.264")?1:0};new AlertDialog.Builder(this).setTitle("Custom video").setView(box).setSingleChoiceItems(codecs,choice[0],(d,w)->choice[0]=w).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{try{recordingSettings.fps=Math.max(15,Math.min(60,Integer.parseInt(fps.getText().toString())));recordingSettings.bitrate=Math.max(1_000_000,Math.min(30_000_000,Integer.parseInt(mbps.getText().toString())*1_000_000));recordingSettings.codec=choice[0]==0?"HEVC":"H.264";savePrefs();Toast.makeText(this,"Saved • "+recordingSettings.summary()+"\n~"+estimate10Min()+" / 10 min",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Invalid values",Toast.LENGTH_SHORT).show();}}).show();}

    private String estimate10Min(){long bytes=(long)((recordingSettings.bitrate+192_000)*600/8.0);if(bytes>=1_000_000_000L)return String.format(Locale.US,"%.2f GB",bytes/1_000_000_000d);return String.format(Locale.US,"%.0f MB",bytes/1_000_000d);}
    private void showSizeInfo(){new AlertDialog.Builder(this).setTitle("File size estimate").setMessage("About "+estimate10Min()+" for 10 minutes at the selected bitrate.\n\nActual size can differ slightly because MP4 overhead and audio are included. Bitrate is the main control for file size.").setPositiveButton("OK",null).show();}

    private void chooseAudioInput(){AudioManager am=(AudioManager)getSystemService(Context.AUDIO_SERVICE);AudioDeviceInfo[] ds=am.getDevices(AudioManager.GET_DEVICES_INPUTS);List<AudioDeviceInfo> usable=new ArrayList<>();List<String> labels=new ArrayList<>();labels.add("Phone microphone (default)");for(AudioDeviceInfo d:ds){String n=d.getProductName()==null?"Audio input":d.getProductName().toString();labels.add(n+" — "+typeName(d.getType()));usable.add(d);}int checked=0;if(selectedInputDeviceId!=null)for(int i=0;i<usable.size();i++)if(usable.get(i).getId()==selectedInputDeviceId)checked=i+1;String[] choices=labels.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("Microphone input").setSingleChoiceItems(choices,checked,(d,w)->{if(w==0){selectedInputDeviceId=null;selectedInputName="Phone microphone (default)";}else{AudioDeviceInfo x=usable.get(w-1);selectedInputDeviceId=x.getId();selectedInputName=x.getProductName().toString();}d.dismiss();Toast.makeText(this,"Input: "+selectedInputName,Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    private String typeName(int t){switch(t){case AudioDeviceInfo.TYPE_BUILTIN_MIC:return"phone mic";case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:return"Bluetooth headset mic";case AudioDeviceInfo.TYPE_BLE_HEADSET:return"Bluetooth LE headset mic";case AudioDeviceInfo.TYPE_WIRED_HEADSET:return"wired headset mic";case AudioDeviceInfo.TYPE_USB_HEADSET:return"USB headset mic";default:return"input";}}

    private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;ProcessCameraProvider.getInstance(this).addListener(()->{try{ProcessCameraProvider p=ProcessCameraProvider.getInstance(this).get();p.unbindAll();camera.setImplementationMode(PreviewView.ImplementationMode.COMPATIBLE);
                Preview prev=new Preview.Builder().build();prev.setSurfaceProvider(camera.getSurfaceProvider());p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,prev);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));}

    private void requestCapture(){if(!hasSource()){Toast.makeText(this,"Choose a source video first.",Toast.LENGTH_LONG).show();return;}if(Build.VERSION.SDK_INT<29){Toast.makeText(this,"Android 10+ is required.",Toast.LENGTH_LONG).show();return;}if(recording)return;applyOrientationForAspect();android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);}
    private void applyOrientationForAspect(){if(recordingSettings.width>recordingSettings.height)setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);else setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}

    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==CAPTURE&&c==RESULT_OK&&d!=null){Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_START);s.putExtra(RecordingService.EXTRA_PROJECTION,d);if(selectedInputDeviceId!=null)s.putExtra(RecordingService.EXTRA_DEVICE_ID,selectedInputDeviceId);s.putExtra(RecordingService.EXTRA_WIDTH,recordingSettings.width);s.putExtra(RecordingService.EXTRA_HEIGHT,recordingSettings.height);s.putExtra(RecordingService.EXTRA_FPS,recordingSettings.fps);s.putExtra(RecordingService.EXTRA_BITRATE,recordingSettings.bitrate);s.putExtra(RecordingService.EXTRA_CODEC,recordingSettings.codec);ContextCompat.startForegroundService(this,s);}}
    private void stopRecording(){Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_STOP);startService(s);record.setText("…"); recordingBadge.setText("●  SAVING…");}

    @Override protected void onDestroy(){uiHandler.removeCallbacks(progressTicker);try{unregisterReceiver(recorderReceiver);}catch(Exception ignored){}if(player!=null)player.release(); if(youtubeView!=null){stopYouTubePlayback(); youtubeView.removeJavascriptInterface("AndroidYT"); youtubeView.destroy();} super.onDestroy();}
}
