package com.reactionrecorder;

import android.Manifest;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends ComponentActivity {
    private FrameLayout root;
    private PreviewView camera;
    private PlayerView source;
    private ExoPlayer player;
    private Button pick, youtube, play, record, settings;
    private Uri sourceUri;
    private boolean recording;
    private Integer selectedInputDeviceId;
    private String selectedInputName = "Phone microphone (default)";
    private AudioVideoRecorder.RecordingSettings recordingSettings = new AudioVideoRecorder.RecordingSettings();
    private static final int CAPTURE = 77;
    private android.content.SharedPreferences prefs;

    private final BroadcastReceiver recorderReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a=intent.getAction();
            if(RecordingService.ACTION_STARTED.equals(a)) {
                recording=true; record.setText("Stop"); Toast.makeText(MainActivity.this,"Recording started",Toast.LENGTH_SHORT).show();
            } else if(RecordingService.ACTION_FINISHED.equals(a)) {
                recording=false; record.setText("Record"); String s=intent.getStringExtra(RecordingService.EXTRA_URI);
                if(s!=null) { Intent share=new Intent(Intent.ACTION_SEND); share.setType("video/mp4"); share.putExtra(Intent.EXTRA_STREAM,Uri.parse(s)); share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                Toast.makeText(MainActivity.this,"Saved to Movies / Reaction Recorder",Toast.LENGTH_LONG).show();
            } else if(RecordingService.ACTION_FAILED.equals(a)) {
                recording=false; record.setText("Record"); Toast.makeText(MainActivity.this,"Recording failed: "+intent.getStringExtra(RecordingService.EXTRA_ERROR),Toast.LENGTH_LONG).show();
            }
        }
    };

    private final ActivityResultLauncher<String[]> perms=registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(),r->startCamera());
    private final ActivityResultLauncher<Intent> picker=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),r->{
        if(r.getResultCode()==RESULT_OK&&r.getData()!=null){sourceUri=r.getData().getData();try{getContentResolver().takePersistableUriPermission(sourceUri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}loadSource(sourceUri);}
    });

    @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(com.reactionrecorder.R.layout.activity_main);
        root=findViewById(R.id.root);camera=findViewById(R.id.camera);source=findViewById(R.id.source);pick=findViewById(R.id.pick);youtube=findViewById(R.id.youtube);play=findViewById(R.id.play);record=findViewById(R.id.record);settings=findViewById(R.id.settings);
        prefs=getSharedPreferences("recorder",MODE_PRIVATE);loadPrefs();
        player=new ExoPlayer.Builder(this).setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true).build();source.setPlayer(player);
        pick.setOnClickListener(v->choose()); youtube.setOnClickListener(v->youtubeDialog()); play.setOnClickListener(v->toggleSource()); record.setOnClickListener(v->{if(!recording)requestCapture();else stopRecording();}); settings.setOnClickListener(v->settingsDialog());
        IntentFilter f=new IntentFilter();f.addAction(RecordingService.ACTION_STARTED);f.addAction(RecordingService.ACTION_FINISHED);f.addAction(RecordingService.ACTION_FAILED);ContextCompat.registerReceiver(this,recorderReceiver,f,ContextCompat.RECEIVER_NOT_EXPORTED);
        perms.launch(new String[]{Manifest.permission.CAMERA,Manifest.permission.RECORD_AUDIO});
    }

    private void loadPrefs(){recordingSettings.codec=prefs.getString("codec","HEVC");recordingSettings.width=prefs.getInt("width",1080);recordingSettings.height=prefs.getInt("height",1920);recordingSettings.fps=prefs.getInt("fps",30);recordingSettings.bitrate=prefs.getInt("bitrate",5_000_000);}
    private void savePrefs(){prefs.edit().putString("codec",recordingSettings.codec).putInt("width",recordingSettings.width).putInt("height",recordingSettings.height).putInt("fps",recordingSettings.fps).putInt("bitrate",recordingSettings.bitrate).apply();}

    private void choose(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("video/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);picker.launch(i);}
    private void loadSource(Uri u){player.setMediaItem(MediaItem.fromUri(u));player.prepare();player.pause();play.setText("Play");}
    private void toggleSource(){if(player.isPlaying()){player.pause();play.setText("Play");}else{player.play();play.setText("Pause");}}
    private void youtubeDialog(){EditText e=new EditText(this);e.setHint("https://www.youtube.com/watch?v=...");new AlertDialog.Builder(this).setTitle("YouTube source").setMessage("Open the link normally. For recording, choose a local video you are authorized to use.").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Open",(d,w)->{String s=e.getText().toString().trim();if(s.startsWith("http://")||s.startsWith("https://"))startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(s)));else Toast.makeText(this,"Enter a valid URL",Toast.LENGTH_SHORT).show();}).show();}

    private void settingsDialog(){String[] items={"Video quality • "+recordingSettings.summary(),"Aspect ratio • "+aspectRatioName(),"Estimated size • "+estimate10Min(),"Audio input • "+selectedInputName,"Audio mix • Mic + source audio"};new AlertDialog.Builder(this).setTitle("Recording settings").setItems(items,(d,w)->{if(w==0)chooseVideoQuality();else if(w==1)chooseAspectRatio();else if(w==2)showSizeInfo();else if(w==3)chooseAudioInput();else Toast.makeText(this,"Both microphone and source playback are included in the final audio.",Toast.LENGTH_LONG).show();}).show();}

    private String aspectRatioName(){float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-16f/9f)<.03f)return"16:9";if(Math.abs(r-9f/16f)<.03f)return"9:16";if(Math.abs(r-1f)<.03f)return"1:1";if(Math.abs(r-4f/3f)<.03f)return"4:3";return"Custom";}
    private void chooseAspectRatio(){String[] c={"9:16 vertical","16:9 landscape","1:1 square","4:3 landscape"};float r=recordingSettings.width/(float)recordingSettings.height;int checked=Math.abs(r-9f/16f)<.03f?0:Math.abs(r-16f/9f)<.03f?1:Math.abs(r-1)<.03f?2:3;new AlertDialog.Builder(this).setTitle("Aspect ratio").setSingleChoiceItems(c,checked,(d,w)->{int longSide=Math.max(recordingSettings.width,recordingSettings.height);if(w==0){recordingSettings.width=even(Math.round(longSide*9f/16f));recordingSettings.height=even(longSide);}else if(w==1){recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*9f/16f));}else if(w==2){recordingSettings.width=even(longSide);recordingSettings.height=even(longSide);}else{recordingSettings.width=even(longSide);recordingSettings.height=even(Math.round(longSide*3f/4f));}savePrefs();d.dismiss();Toast.makeText(this,"Aspect ratio: "+aspectRatioName(),Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    private int even(int n){return Math.max(2,n&~1);}

    private void chooseVideoQuality(){String[] c={"HEVC • 1080p • 30 • 5 Mbps","HEVC • 1080p • 30 • 8 Mbps","H.264 • 1080p • 30 • 8 Mbps","HEVC • 720p • 30 • 3 Mbps","Custom"};new AlertDialog.Builder(this).setTitle("Video quality").setItems(c,(d,w)->{if(w==0)applyPreset("HEVC",1080,30,5_000_000);else if(w==1)applyPreset("HEVC",1080,30,8_000_000);else if(w==2)applyPreset("H.264",1080,30,8_000_000);else if(w==3)applyPreset("HEVC",720,30,3_000_000);else customQualityDialog();}).show();}
    private void applyPreset(String codec,int longSide,int fps,int bitrate){recordingSettings.codec=codec;recordingSettings.fps=fps;recordingSettings.bitrate=bitrate;boolean vert=recordingSettings.height>recordingSettings.width;float r=recordingSettings.width/(float)recordingSettings.height;if(Math.abs(r-1)<.03f){recordingSettings.width=longSide;recordingSettings.height=longSide;}else if(Math.abs(r-4f/3f)<.08f){recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*3f/4f);}else if(vert){recordingSettings.height=longSide;recordingSettings.width=Math.round(longSide*9f/16f);}else{recordingSettings.width=longSide;recordingSettings.height=Math.round(longSide*9f/16f);}recordingSettings.width=even(recordingSettings.width);recordingSettings.height=even(recordingSettings.height);savePrefs();Toast.makeText(this,"Quality: "+recordingSettings.summary()+"\nEstimated 10 min: "+estimate10Min(),Toast.LENGTH_LONG).show();}

    private void customQualityDialog(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);int p=(int)(16*getResources().getDisplayMetrics().density);box.setPadding(p,0,p,0);EditText fps=new EditText(this);fps.setHint("FPS 15–60");fps.setInputType(2);fps.setText(String.valueOf(recordingSettings.fps));EditText mbps=new EditText(this);mbps.setHint("Bitrate Mbps 1–30");mbps.setInputType(2|8192);mbps.setText(String.valueOf(Math.max(1,recordingSettings.bitrate/1_000_000)));box.addView(fps);box.addView(mbps);String[] codecs={"HEVC (H.265)","H.264 (AVC)"};final int[] choice={recordingSettings.codec.equals("H.264")?1:0};new AlertDialog.Builder(this).setTitle("Custom video").setView(box).setSingleChoiceItems(codecs,choice[0],(d,w)->choice[0]=w).setNegativeButton("Cancel",null).setPositiveButton("Apply",(d,w)->{try{recordingSettings.fps=Math.max(15,Math.min(60,Integer.parseInt(fps.getText().toString())));recordingSettings.bitrate=Math.max(1_000_000,Math.min(30_000_000,Integer.parseInt(mbps.getText().toString())*1_000_000));recordingSettings.codec=choice[0]==0?"HEVC":"H.264";savePrefs();Toast.makeText(this,"Saved • "+recordingSettings.summary()+"\n~"+estimate10Min()+" / 10 min",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Invalid values",Toast.LENGTH_SHORT).show();}}).show();}

    private String estimate10Min(){long bytes=(long)((recordingSettings.bitrate+192_000)*600/8.0);if(bytes>=1_000_000_000L)return String.format(Locale.US,"%.2f GB",bytes/1_000_000_000d);return String.format(Locale.US,"%.0f MB",bytes/1_000_000d);}
    private void showSizeInfo(){new AlertDialog.Builder(this).setTitle("File size estimate").setMessage("About "+estimate10Min()+" for 10 minutes at the selected bitrate.\n\nActual size can differ slightly because MP4 overhead and audio are included. Bitrate is the main control for file size.").setPositiveButton("OK",null).show();}

    private void chooseAudioInput(){AudioManager am=(AudioManager)getSystemService(Context.AUDIO_SERVICE);AudioDeviceInfo[] ds=am.getDevices(AudioManager.GET_DEVICES_INPUTS);List<AudioDeviceInfo> usable=new ArrayList<>();List<String> labels=new ArrayList<>();labels.add("Phone microphone (default)");for(AudioDeviceInfo d:ds){String n=d.getProductName()==null?"Audio input":d.getProductName().toString();labels.add(n+" — "+typeName(d.getType()));usable.add(d);}int checked=0;if(selectedInputDeviceId!=null)for(int i=0;i<usable.size();i++)if(usable.get(i).getId()==selectedInputDeviceId)checked=i+1;String[] choices=labels.toArray(new String[0]);new AlertDialog.Builder(this).setTitle("Microphone input").setSingleChoiceItems(choices,checked,(d,w)->{if(w==0){selectedInputDeviceId=null;selectedInputName="Phone microphone (default)";}else{AudioDeviceInfo x=usable.get(w-1);selectedInputDeviceId=x.getId();selectedInputName=x.getProductName().toString();}d.dismiss();Toast.makeText(this,"Input: "+selectedInputName,Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
    private String typeName(int t){switch(t){case AudioDeviceInfo.TYPE_BUILTIN_MIC:return"phone mic";case AudioDeviceInfo.TYPE_BLUETOOTH_SCO:return"Bluetooth headset mic";case AudioDeviceInfo.TYPE_BLE_HEADSET:return"Bluetooth LE headset mic";case AudioDeviceInfo.TYPE_WIRED_HEADSET:return"wired headset mic";case AudioDeviceInfo.TYPE_USB_HEADSET:return"USB headset mic";default:return"input";}}

    private void startCamera(){if(ContextCompat.checkSelfPermission(this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)return;ProcessCameraProvider.getInstance(this).addListener(()->{try{ProcessCameraProvider p=ProcessCameraProvider.getInstance(this).get();p.unbindAll();Preview prev=new Preview.Builder().build();prev.setSurfaceProvider(camera.getSurfaceProvider());p.bindToLifecycle(this,CameraSelector.DEFAULT_FRONT_CAMERA,prev);}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}},ContextCompat.getMainExecutor(this));}

    private void requestCapture(){if(sourceUri==null){Toast.makeText(this,"Choose a source video first.",Toast.LENGTH_LONG).show();return;}if(Build.VERSION.SDK_INT<29){Toast.makeText(this,"Android 10+ is required.",Toast.LENGTH_LONG).show();return;}if(recording)return;applyOrientationForAspect();android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),CAPTURE);}
    private void applyOrientationForAspect(){if(recordingSettings.width>recordingSettings.height)setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);else setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);}

    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==CAPTURE&&c==RESULT_OK&&d!=null){Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_START);s.putExtra(RecordingService.EXTRA_PROJECTION,d);if(selectedInputDeviceId!=null)s.putExtra(RecordingService.EXTRA_DEVICE_ID,selectedInputDeviceId);s.putExtra(RecordingService.EXTRA_WIDTH,recordingSettings.width);s.putExtra(RecordingService.EXTRA_HEIGHT,recordingSettings.height);s.putExtra(RecordingService.EXTRA_FPS,recordingSettings.fps);s.putExtra(RecordingService.EXTRA_BITRATE,recordingSettings.bitrate);s.putExtra(RecordingService.EXTRA_CODEC,recordingSettings.codec);ContextCompat.startForegroundService(this,s);}}
    private void stopRecording(){Intent s=new Intent(this,RecordingService.class);s.setAction(RecordingService.ACTION_STOP);startService(s);record.setText("Saving…");}

    @Override protected void onDestroy(){try{unregisterReceiver(recorderReceiver);}catch(Exception ignored){}if(player!=null)player.release();super.onDestroy();}
}
