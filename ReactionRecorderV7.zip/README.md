# Reaction Recorder V7

V7 is a stability-focused recording engine update. It keeps the one-phone reaction workflow while hardening Android's modern MediaProjection/foreground-service lifecycle, audio capture, codec selection, and recording settings.

## Recording
- Android foreground recording service with `mediaProjection` + `microphone` service types for Android 14+.
- H.265/HEVC with capability detection and automatic H.264 fallback.
- H.264/AVC compatibility mode.
- Encoder-aware resolution/FPS/bitrate validation; unsupported combinations are reduced instead of blindly configured.
- MP4 output with AAC audio.
- 9:16, 16:9, 1:1 and 4:3 output dimension presets. Landscape recording switches the activity to landscape before capture.
- 15–60 FPS custom setting and adjustable video bitrate.
- Approximate 10-minute file-size estimate based on selected video + AAC bitrate.
- Recording settings persist between launches.

## Audio
- Separate microphone and Android playback-capture inputs.
- Select an Android-exposed microphone/input device, including phone mic, Bluetooth headset mic, wired headset mic, USB input, etc.
- Playback audio is captured digitally, so the source audio can still be included while the user listens through earbuds.
- Audio input workers are decoupled and the mixer fills missing chunks with silence rather than blocking the whole pipeline.
- AAC output is drained until EOS before the MP4 is finalized.

## Important platform behavior
Android's playback-capture API is subject to the source app's capture policy. Some apps can prevent their audio from being captured. This app does not bypass those restrictions.

## YouTube
The YouTube URL button opens the URL using the normal Android handler. It does not download or bypass access restrictions. For recording, use a local video you are authorized to use.

## Build
The included GitHub Actions workflow builds a debug APK using JDK 17, Android SDK 35, and Gradle 8.7. No local Android toolchain is required if you use GitHub Actions.

## Still a development build
A real release should be tested on the target Samsung/Android device for HEVC encoder behavior, camera orientation, Bluetooth routing, playback-capture availability, long recordings, thermal behavior, and interrupted recordings.
